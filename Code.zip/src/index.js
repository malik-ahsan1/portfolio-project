// =============================================================================
// SCROLL FUNCTIONALITY
// =============================================================================

// Scroll state variables
let currentY = 0;
let targetY = 0;
const ease = 0.6;

let hasAnimatedMessageMe = false;

// Animation state variables
const startScroll = -3780;
const endScroll = -3900;

// DOM elements for scroll
const wrapper = document.getElementById('mainWrapper');
const container = document.getElementById('scroll-container');
const scrollObj = { y: 0 };

// Wheel event handler
function onWheel(e) {
    e.preventDefault();
    // Adjust scroll position based on wheel delta
    scrollObj.y -= e.deltaY * ease;
    const maxScroll = 3900;
    scrollObj.y = Math.max(Math.min(scrollObj.y, 0), -maxScroll);
    targetY = scrollObj.y;
}

// Initialize scroll functionality
function initializeScroll() {
    document.addEventListener('wheel', onWheel, { passive: false });

    // GSAP ticker for smooth scrolling
    gsap.ticker.add(() => {
        currentY += (targetY - currentY) * 0.3;
        gsap.to(container, {
            y: currentY,
            duration: 0.1,
            ease: 'expo.out',
        });

        // === Navbar direction detection ===
        if (currentY < previousScrollY - 5 && !isNavbarHidden) {
            moveUpNavbar();
            isNavbarHidden = true;
        } else if (
            (currentY > previousScrollY + 5 && isNavbarHidden) ||
            currentY + 3900 < 1
        ) {
            moveDownNavbar();
            isNavbarHidden = false;
        }
        previousScrollY = currentY;

        // Check if we reached -145 to trigger about header animation
        if (!hasAnimatedAboutHeader && currentY + 200 < 1) {
            hasAnimatedAboutHeader = true;
            animateHeader(aboutHeader);
        }

        // Check if we reached -300 to trigger line animation
        if (!hasAnimatedLineIntro && currentY + 300 < 1) {
            hasAnimatedLineIntro = true;
            drawLine(animatedLineIntro);
        }

        if (!hasAnimatedIntroPara && currentY + 400 < 1) {
            hasAnimatedIntroPara = true;
            animateParagraph(introPara);
        }

        // Check if we reached -700 to trigger projects circle animation
        if (!hasAnimatedLearnMoreCircle && currentY + 700 < 1) {
            hasAnimatedLearnMoreCircle = true;
            animateCircle(mainCircleIntro, innerContentIntro);
        }

        // Check if we reached -1450 to trigger about header animation
        if (!hasAnimatedProjectsHeader && currentY + 1400 < 1) {
            hasAnimatedProjectsHeader = true;
            animateHeader(projectsHeader);
        }

        // Check if we reached -1550 to trigger line animation
        if (!hasAnimatedLineProjects && currentY + 1500 < 1) {
            hasAnimatedLineProjects = true;
            drawLine(animatedLineProjects);
        }

        // Check if we reached -1650 to trigger projects circle animation
        if (!hasAnimatedViewAllProductsCircle && currentY + 1600 < 1) {
            hasAnimatedViewAllProductsCircle = true;
            animateCircle(mainCircleProjects, innerContentProjects);
        }

        if (!hasAnimatedProjectsPara && currentY + 1650 < 1) {
            hasAnimatedProjectsPara = true;
            animateParagraph(projectsPara, 0.6, 0, 0.2);
        }

        if (!hasAnimatedCapabilitiesHeader && currentY + 3000 < 1) {
            hasAnimatedCapabilitiesHeader = true;
            animateHeader(capabilitiesHeader);
        }

        if (!hasAnimatedLineCapabilites && currentY + 3050 < 1) {
            hasAnimatedLineCapabilites = true;
            drawLine(animatedLineCapabilites);
        }

        const progress = gsap.utils.clamp(
            0,
            1,
            (currentY - startScroll) / (endScroll - startScroll)
        );

        // Toggle border based on progress
        if (progress > 0) {
            if (!wrapper.classList.contains('border')) {
                wrapper.classList.add('border-2', 'border-white/40');
            }
        } else {
            wrapper.classList.remove('border-2', 'border-white/40');
        }

        const width = gsap.utils.interpolate(
            window.innerWidth,
            window.innerWidth * 0.93,
            progress
        );
        const height = gsap.utils.interpolate(
            window.innerHeight,
            window.innerHeight * 0.78,
            progress
        );
        const yPercent = gsap.utils.interpolate(-50, -46, progress);

        gsap.to(wrapper, {
            width: width,
            height: height,
            yPercent: yPercent,
            duration: 0.1,
        });

        const elementOffsetY = gsap.utils.interpolate(0, -140, progress); // adjust -100 as needed
        gsap.to('.message-me', {
            y: elementOffsetY,
            duration: 0.1,
        });

        if (
            currentY <= endScroll + 1 &&
            !wrapper.classList.contains('w-[93vw]')
        ) {
            wrapper.classList.remove('w-screen', 'h-screen');
            wrapper.classList.add('w-[93vw]', 'h-[78vh]');
        }
    });
}

// =============================================================================
// NAVBAR ANIMATION
// =============================================================================

const navbar = document.querySelector('.navbar');

let previousScrollY = 0;
let isNavbarHidden = false;

function moveUpNavbar() {
    gsap.to(navbar, {
        yPercent: -100,
        duration: 1.5,
        ease: 'expo.out',
    });
}

function moveDownNavbar() {
    gsap.to(navbar, {
        yPercent: 0,
        duration: 1.5,
        ease: 'expo.out',
    });
}

// =============================================================================
// PARAGRAPH ANIMATION
// =============================================================================

function initializeParagraphAnimation(para) {
    gsap.set(para, {
        yPercent: 100,
        opacity: 0,
    });
}

function animateParagraph(para, duration = 0.4, delay = 0.4, stagger = 0.1) {
    gsap.to(para, {
        yPercent: 0,
        opacity: 1,
        duration: duration,
        ease: 'power2.out',
        delay: delay,
        stagger: stagger,
    });
}

// =============================================================================
// HERO PARAGRAPH ANIMATION
// =============================================================================

const heroPara = document.querySelectorAll('.hero-description > span > span');
let hasAnimatedHeroPara = false;

// =============================================================================
// CIRCLE INTERACTION
// =============================================================================

// Hero circle state variables
let isHovering = false;
let mousePosition = { x: 0, y: 0 };
const maxDistance = 110; // Maximum distance the circle can move from center

// Initialize circle interactions
function initializeCircle(
    detectionArea,
    topCircle,
    bottomCircle,
    getInnerContent,
    onClick,
    mouseenter,
    mouseleave
) {
    // Set initial arrow state
    gsap.set(getInnerContent(), {
        opacity: 0,
        x: 0,
        y: -25,
    });

    // Click event
    detectionArea.addEventListener('click', onClick);

    // Mouse enter event
    detectionArea.addEventListener('mouseenter', mouseenter);

    // Mouse leave event
    detectionArea.addEventListener('mouseleave', mouseleave);

    // Mouse move event
    detectionArea.addEventListener('mousemove', (e) => {
        if (!isHovering) return;

        // Get container bounds
        const rect = detectionArea.getBoundingClientRect();
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        // Calculate mouse position relative to container center
        const mouseX = e.clientX - rect.left - centerX;
        const mouseY = e.clientY - rect.top - centerY;

        // Calculate distance from center
        const distance = Math.sqrt(mouseX * mouseX + mouseY * mouseY);

        let targetX, targetY;

        if (distance <= maxDistance) {
            // Mouse is within allowed range
            targetX = mouseX;
            targetY = mouseY;
        } else {
            // Limit movement to maxDistance
            const angle = Math.atan2(mouseY, mouseX);
            targetX = Math.cos(angle) * maxDistance;
            targetY = Math.sin(angle) * maxDistance;
        }

        // Animate elements to follow mouse
        gsap.to(topCircle, {
            x: targetX,
            y: targetY,
            duration: 1.5,
            ease: 'expo.out',
        });

        gsap.to(bottomCircle, {
            x: targetX * 0.3,
            y: targetY * 0.3,
            duration: 1.5,
            ease: 'expo.out',
        });

        gsap.to(getInnerContent(), {
            x: targetX * 0.35,
            y: targetY * 0.35,
            duration: 1.5,
            ease: 'expo.out',
        });
    });
}

// =============================================================================
// MAIN CIRCLE ANIMATION
// =============================================================================

// Main circle elements and configuration
const radius = 90;
const circumference = 2 * Math.PI * radius;

// Initialize main circle animation
function initializeMainCircle(mainCircle) {
    // Set initial opacity
    mainCircle[0].style.opacity = '0';
    mainCircle[1].style.opacity = '0';

    // Set initial state - circle is invisible
    mainCircle.forEach((circle) => {
        gsap.set(circle, {
            strokeDasharray: circumference,
            strokeDashoffset: circumference,
            transformOrigin: 'center center',
        });
    });
}

// Animate main circle drawing
function animateCircle(mainCircle, innerContent) {
    const tl = gsap.timeline();

    // Reset circle to invisible state
    mainCircle.forEach((circle) => {
        tl.set(circle, {
            strokeDashoffset: circumference,
        });
    });

    // Animate the circle drawing and rotation
    mainCircle.forEach((circle) => {
        tl.to(
            circle,
            {
                rotate: 360,
                strokeDashoffset: 0,
                opacity: 2,
                duration: 2.2,
                ease: 'expo.out',
            },
            '<'
        );
    });

    // Animate arrow appearance
    tl.to(
        innerContent,
        {
            opacity: 1,
            y: 0,
            duration: 0.5,
            ease: 'power2.out',
        },
        '<'
    );

    return tl;
}

// =============================================================================
// HERO CIRCLE INTERACTION
// =============================================================================

// DOM elements for hero circle
const detectionAreaHero = document.getElementById('circle-area-hero');
const topCircleHero = document.querySelector('.circle-area-hero__top-circle');
const bottomCircleHero = document.querySelector(
    '.circle-area-hero__bottom-circle'
);
const mainCircleHero = Array.from(
    document.querySelectorAll('.mainCircle-hero')
);
const innerContentHero = document.querySelector('.circle-area-hero__arrow');

// Hero circle interaction functions
function onClickHeroCircle() {
    gsap.to(scrollObj, {
        y: -1104,
        duration: 2.2,
        ease: 'expo.inOut',
        onUpdate: () => {
            targetY = scrollObj.y;
        },
    });
}

function mouseenterHeroCircle() {
    isHovering = true;
}

function mouseleaveHeroCircle() {
    isHovering = false;
    // Return to resting position (center)
    gsap.to([topCircleHero, bottomCircleHero, innerContentHero], {
        x: 0,
        y: 0,
        duration: 1.5,
        ease: 'expo.out',
    });
}

// =============================================================================
// LINE ANIMATION FUNCTIONALITY
// =============================================================================

// Calculate line length for stroke-dash animation
function calculateLineLength(animatedLine) {
    const svg = animatedLine.closest('svg');
    const rect = svg.getBoundingClientRect();
    return rect.width;
}

// Set initial state - line is invisible
function initializeLine(animatedLine) {
    let lineLength = calculateLineLength(animatedLine);

    gsap.set(animatedLine, {
        strokeDasharray: lineLength,
        strokeDashoffset: lineLength,
    });
}

// Animate line drawing from left to right
function drawLine(animatedLine) {
    let lineLength = calculateLineLength(animatedLine);

    // Reset line to invisible state
    gsap.set(animatedLine, {
        strokeDasharray: lineLength,
        strokeDashoffset: lineLength,
    });

    // Animate the line drawing
    gsap.to(animatedLine, {
        strokeDashoffset: 0,
        duration: 2,
        ease: 'power2.inOut',
    });
}

// =============================================================================
// INTRO LINE ANIMATION
// =============================================================================

// Line animation state and elements
const animatedLineIntro = document.getElementById('animated-line-intro');
let hasAnimatedLineIntro = false;

// =============================================================================
// HEADER ANIMATION
// =============================================================================

function initializeHeader(header) {
    gsap.set(header, {
        y: 20,
        opacity: 0,
    });
}

function animateHeader(aboutHeader) {
    gsap.to(aboutHeader, {
        y: 0,
        opacity: 1,
        duration: 0.5,
        ease: 'power2.out',
        delay: 0.5,
    });
}

// ==============================================================================
// ABOUT HEADER ANIMATION
// =============================================================================

const aboutHeader = document.querySelector('.about-header');
let hasAnimatedAboutHeader = false;

// ==============================================================================
// INTRO PARAGRAPH ANIMATION
// =============================================================================

const introPara = document.querySelectorAll('.intro-para > span > span');
let hasAnimatedIntroPara = false;

// =============================================================================
// INTRO CIRCLE INTERACTION
// =============================================================================

// DOM elements for hero circle
const detectionAreaIntro = document.getElementById('circle-area-intro');
const topCircleIntro = document.querySelector('.circle-area-intro__top-circle');
const bottomCircleIntro = document.querySelector(
    '.circle-area-intro__bottom-circle'
);
const mainCircleIntro = Array.from(
    document.querySelectorAll('.mainCircle-intro')
);
let innerContentIntro = document.querySelector('.learn-more-btn__text');

let hasAnimatedLearnMoreCircle = false;

function mouseenterIntroCircle() {
    isHovering = true;

    innerContentIntro.style.opacity = '0';
    innerContentIntro = document.querySelector('.circle-area-intro__arrow');
    innerContentIntro.style.opacity = '1';
}

function mouseleaveIntroCircle() {
    isHovering = false;

    innerContentIntro.style.opacity = '0';
    innerContentIntro = document.querySelector('.learn-more-btn__text');
    innerContentIntro.style.opacity = '1';

    // Return to resting position (center)
    gsap.to([topCircleIntro, bottomCircleIntro, innerContentIntro], {
        x: 0,
        y: 0,
        duration: 1.5,
        ease: 'expo.out',
    });
}

// =============================================================================
// MOVING STRIPE ANIMATION
// =============================================================================

function createLiquidHorizontalScroll() {
    const movingStrip = document.querySelectorAll('.marquee');

    gsap.to(movingStrip, {
        xPercent: -100,
        ease: 'none',
        duration: 8,
        repeat: -1,
        modifiers: {
            xPercent: gsap.utils.wrap(-100, 0),
        },
    });
}

// =============================================================================
// PROJECTS LINE ANIMATION
// =============================================================================

// Line animation state and elements
const animatedLineProjects = document.getElementById('animated-line-projects');
let hasAnimatedLineProjects = false;

// ==============================================================================
// PROJECTS HEADER ANIMATION
// =============================================================================

const projectsHeader = document.querySelector('.projects-header');
let hasAnimatedProjectsHeader = false;

// ==============================================================================
// VIEW ALL PROJECTS CIRCLE INTERACTION
// =============================================================================

// DOM elements for hero circle
const detectionAreaProjects = document.getElementById('circle-area-projects');
const topCircleProjects = document.querySelector(
    '.circle-area-projects__top-circle'
);
const bottomCircleProjects = document.querySelector(
    '.circle-area-projects__bottom-circle'
);
const mainCircleProjects = Array.from(
    document.querySelectorAll('.mainCircle-projects')
);
let innerContentProjects = document.querySelector('.view-all-projects__text');

let hasAnimatedViewAllProductsCircle = false;

function mouseenterProjectsCircle() {
    isHovering = true;

    innerContentProjects.style.opacity = '0';
    innerContentProjects = document.querySelector(
        '.circle-area-projects__arrow'
    );
    innerContentProjects.style.opacity = '1';
}

function mouseleaveProjectsCircle() {
    isHovering = false;

    innerContentProjects.style.opacity = '0';
    innerContentProjects = document.querySelector('.view-all-projects__text');
    innerContentProjects.style.opacity = '1';

    // Return to resting position (center)
    gsap.to([topCircleProjects, bottomCircleProjects, innerContentProjects], {
        x: 0,
        y: 0,
        duration: 1.5,
        ease: 'expo.out',
    });
}

// =============================================================================
// PROJECTS PARAGRAPH ANIMATION
// =============================================================================

const projectsPara = document.querySelectorAll(
    '.projects-description > span > span'
);
let hasAnimatedProjectsPara = false;

// =============================================================================
// FEATURED PRODUCTS ANIMATION
// =============================================================================

const featuredProjectTitles = Array.from(
    document.querySelectorAll('.project-title-featured span')
);

featuredProjectTitles.forEach((project) => {
    gsap.set(project, {
        yPercent: 100,
        opacity: 0,
    });
});

const projectImages = [
    document.querySelector('.img1'),
    document.querySelector('.img2'),
    document.querySelector('.img3'),
];

const projectInfos = [
    document.querySelector('.img1-info'),
    document.querySelector('.img2-info'),
    document.querySelector('.img3-info'),
];

const hoverText = document.querySelector('#hoverText');

// Initialize project hover interactions
function initializeProjectHover() {
    projectImages.forEach((image, index) => {
        if (!image) return;

        const overlays = projectImages.map((img) =>
            img.querySelector('.overlay')
        );

        image.addEventListener('mouseenter', () => {
            // Show hover text
            gsap.set([hoverText, projectInfos[index]], { opacity: 1 });

            // Animate current title
            gsap.to(featuredProjectTitles[index], {
                yPercent: 0,
                opacity: 1,
                duration: 0.15,
                ease: 'power1.out',
            });

            // Fade in overlays on other images
            overlays.forEach((overlay, i) => {
                if (i !== index) {
                    gsap.to(overlay, {
                        opacity: 1,
                        duration: 0.15,
                        ease: 'power1.out',
                    });
                }
            });
        });

        image.addEventListener('mouseleave', () => {
            // Hide hover text
            gsap.set([hoverText, projectInfos[index]], { opacity: 0 });

            // Hide current title
            gsap.to(featuredProjectTitles[index], {
                yPercent: -100,
                opacity: 0,
                duration: 0.15,
                ease: 'power1.out',
                onComplete: () => {
                    gsap.set(featuredProjectTitles[index], {
                        yPercent: 100,
                    });
                },
            });

            // Fade out all overlays
            overlays.forEach((overlay) => {
                gsap.to(overlay, {
                    opacity: 0,
                    duration: 0.15,
                    ease: 'power1.out',
                });
            });
        });
    });
}

// =============================================================================
// CAPABILITES LINE ANIMATION
// =============================================================================

// Line animation state and elements
const animatedLineCapabilites = document.getElementById(
    'animated-line-capabilities'
);
let hasAnimatedLineCapabilites = false;

// ==============================================================================
// CAPABILITIES HEADER ANIMATION
// =============================================================================

const capabilitiesHeader = document.querySelector('.capabilities-header');
let hasAnimatedCapabilitiesHeader = false;

// =============================================================================
// MESSAGES ME ONCLICK
// =============================================================================

const messageMeButton = document.querySelector('.message-btn');

messageMeButton.addEventListener('click', () => {
    window.location.href = './message.html';
});

// =============================================================================
// INITIALIZATION & EVENT LISTENERS
// =============================================================================

// Initialize all functionality when page loads
window.addEventListener('load', () => {
    initializeScroll();
    initializeParagraphAnimation(heroPara);
    initializeCircle(
        detectionAreaHero,
        topCircleHero,
        bottomCircleHero,
        () => innerContentHero,
        onClickHeroCircle,
        mouseenterHeroCircle,
        mouseleaveHeroCircle
    );
    initializeMainCircle(mainCircleHero);
    initializeLine(animatedLineIntro);
    initializeHeader(aboutHeader);
    initializeParagraphAnimation(introPara);
    initializeCircle(
        detectionAreaIntro,
        topCircleIntro,
        bottomCircleIntro,
        () => innerContentIntro,
        () => {},
        mouseenterIntroCircle,
        mouseleaveIntroCircle
    );
    initializeMainCircle(mainCircleIntro);
    createLiquidHorizontalScroll();
    initializeLine(animatedLineProjects);
    initializeHeader(projectsHeader);
    initializeCircle(
        detectionAreaProjects,
        topCircleProjects,
        bottomCircleProjects,
        () => innerContentProjects,
        () => {},
        mouseenterProjectsCircle,
        mouseleaveProjectsCircle
    );
    initializeMainCircle(mainCircleProjects);
    initializeParagraphAnimation(projectsPara);
    initializeProjectHover();
    initializeLine(animatedLineCapabilites);
    initializeHeader(capabilitiesHeader);

    // Start main circle animation after delay
    setTimeout(() => {
        animateParagraph(heroPara);
        animateCircle(mainCircleHero, innerContentHero);
    }, 200);
});

// Handle window resize
window.addEventListener('resize', () => {
    if (lineLength) {
        initializeLine();
    }
});
